# FPS Overlay

Tweak (dylib) hiển thị FPS thời gian thực trên màn hình, điều khiển bật/tắt từ một trang web (`index.html`) thông qua một HTTP server nhỏ chạy ngay trong dylib (cổng `8123` trên chính thiết bị).

## Cấu trúc

- `make.dylib.m` — mã nguồn chính: đo FPS bằng `CADisplayLink`, hiển thị overlay, và mở server HTTP cục bộ để nhận lệnh bật/tắt.
- `Makefile`, `control`, `FPSOverlay.plist` — cấu hình chuẩn của Theos để build ra file `.dylib`/`.deb`.
- `.github/workflows/main.yml` — CI build tự động trên GitHub Actions (chạy trên `macos-latest`, cần Theos).
- `index.html` — giao diện web: hiển thị số FPS, có nút bật/tắt.

## Build

Repo dùng [Theos](https://theos.dev). Khi push lên GitHub, workflow `main.yml` sẽ tự cài Theos và chạy `make package`, kết quả là file `.deb` (cài qua Filza/Sileo) và file `.dylib` thô, tải về ở tab **Actions → Artifacts**.

Build local (đã cài Theos + Xcode command line tools):

```bash
export THEOS=/path/to/theos
make package FINALPACKAGE=1
```

## Cách hoạt động

1. Khi dylib được nạp vào tiến trình đích, nó tạo một `UILabel` overlay (ẩn theo mặc định) và khởi động một HTTP server cục bộ ở cổng `8123`.
2. Mở `index.html` trên trình duyệt điện thoại (hoặc máy tính cùng mạng LAN với thiết bị), nhập IP của thiết bị.
3. Nhấn **Bật overlay** → web gọi `GET /toggle?on=1` → dylib bật `CADisplayLink`, tính FPS mỗi giây và cập nhật label trên màn hình.
4. Web UI tự động poll `GET /fps` mỗi giây để hiển thị số FPS hiện tại.

## Chỉnh mục tiêu injection

Mặc định `FPSOverlay.plist` chỉ target `com.apple.springboard` (an toàn để test). Muốn overlay xuất hiện trong app/game **của chính bạn**, sửa `Bundles` trong file này thành bundle ID app đó — chỉ nên làm với app bạn sở hữu hoặc có quyền chỉnh sửa.

## Lưu ý

- Cổng `8123` chỉ nghe trên chính thiết bị (localhost/LAN), không có xác thực — chỉ dùng trong mạng tin cậy, không mở port này ra Internet.
- Đây là công cụ đo hiệu năng (giám sát khung hình), không đọc/ghi bộ nhớ tiến trình khác.
